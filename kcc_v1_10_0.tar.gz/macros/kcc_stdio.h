#ifndef KCC_STDIO_H
#define KCC_STDIO_H

// Always include the system stdio first
#include_next <stdio.h>

// Add your custom macros/extensions here

#endif
