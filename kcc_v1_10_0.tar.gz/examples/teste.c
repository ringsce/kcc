#include <stdio.h>

int main() {
    printf("Hello from the KCC compiler!\n");
    printf("The number is: %d\n", 42);
    return 0;
}

