int main() {
    int x = 42;
    int y = 10;
    int result = x + y;
    if (result > 50) {
        return 1;
    } else {
        return 0;
    }
}
